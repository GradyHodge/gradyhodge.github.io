
public class A1dot1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Computer Science");
		System.out.println("Programming is fun.");
	}

}
