
public class A1dot2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		// example Syntax of For Loop
		// for(int i=1; i<11; i++){
        //System.out.println("Count is: " + i);
		
		for (int i=0; i<5; i++) {
			System.out.println("Welcome to Java");
		}
	}

}
