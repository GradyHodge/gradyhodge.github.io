


public class A2dot1 {
	// TODO Auto-generated method stub
    // disclosure: I am over my head with the instructions to "intro" to Java
	// I had to get a lot of help to even begin this assignment
	// I am very sensetive to plaigarism but I have no idea how to complete these assignments
	//     based on the materials provided
	
	// I've done my best to do things on my own and utilize what I learned in week one
	// Maybe there are TOO many gifted people in this class who already know how to do this
	// The reading material, the PPT slides, the classroom instruction didn't have anything to do with 
	//    the challenges of this homework assignment.
	
	import java.util.*;
//import java.util.Scanner*;
	 
	 
	 class FtoC {
		 
	public static void main(String[] args) {
	
		float   temp;
		     Scanner in = new Scanner(System.in );
		     System.out.println("Enter temp in Fehranheit");
		         temp = in.nextInt();
		         temp = ((temp - 32)*5)/9;
		
		System.out.println("temp in C = " + temp);
		 
		 }
	}

